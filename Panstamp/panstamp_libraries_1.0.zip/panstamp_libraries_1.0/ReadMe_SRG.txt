panStamp Libraries April 2012
Source: https://code.google.com/p/panstamp/downloads/list
Zip Download: https://code.google.com/p/panstamp/downloads/detail?name=panstamp_arduino_1.0.zip&can=2&q=